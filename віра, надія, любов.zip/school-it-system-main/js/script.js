﻿document.addEventListener("DOMContentLoaded", function () {

     

    const loginBtn = document.querySelector(".btn");
    const heroText = document.querySelector(".hero p");

    loginBtn.addEventListener("click", function (event) {
        event.preventDefault();

        let userName = prompt("Будь ласка, введіть ваше ім'я для входу в SchoolSpace:", "");

        if (userName === null || userName.trim() === "") {
            alert("Вхід скасовано. Будь ласка, введіть ім'я наступного разу.");
        } else {
            let isStudent = confirm("Чи є ви учнем цієї школи? (ОК - Так, Скасувати - Ні, я викладач/директор)");
            let role = isStudent ? "Учень" : "Співробітник";

            alert("Вітаємо в системі, " + userName + "! Ваша роль: " + role);

            heroText.innerText = "Вітаємо, " + userName + "! Ви авторизовані як " + role + ". Оберіть необхідний функціонал нижче.";
            heroText.style.color = "#0d47a1";
            heroText.style.fontWeight = "bold";

            loginBtn.innerText = "Вийти з кабінету";
            loginBtn.style.backgroundColor = "#d32f2f";
        }
    });

    

    const navMenu = document.querySelector(".header nav ul");
    const clockLi = document.createElement("li"); 

    clockLi.style.color = "#90caf9";
    clockLi.style.fontWeight = "bold";
    navMenu.appendChild(clockLi); 

    
    function updateClock() {
        const now = new Date();
        clockLi.innerText = "Час: " + now.toLocaleTimeString('uk-UA');
    }

    setInterval(updateClock, 1000); 
    updateClock(); 

   

    const roleCards = document.querySelectorAll(".role-card");

    for (let i = 0; i < roleCards.length; i++) {

        
        roleCards[i].addEventListener("mouseenter", function () {
            this.style.backgroundColor = "#e3f2fd";
            this.style.boxShadow = "0 12px 25px rgba(13, 71, 161, 0.2)";
            this.style.cursor = "pointer";
        });

        roleCards[i].addEventListener("mouseleave", function () {
            this.style.backgroundColor = "#fff";
            this.style.boxShadow = "0 8px 15px rgba(0,0,0,0.05)";
        });

        
        roleCards[i].addEventListener("click", function () {
            let roleTitle = this.querySelector("h3").innerText;
            let message = "";

            
            switch (roleTitle) {
                case "Директор":
                    message = "У вас 3 нових звіти на підпис.";
                    break;
                case "Викладач":
                    message = "Нагадування: заповніть журнал до 15:00.";
                    break;
                case "Учень":
                    message = "У вас нове домашнє завдання з програмування!";
                    break;
                default:
                    message = "Інформація завантажується...";
            }

            
            let existingMsg = this.querySelector(".dynamic-msg");
            if (existingMsg) {
                existingMsg.remove();
            }

            
            let msgBox = document.createElement("div");
            msgBox.className = "dynamic-msg";
            msgBox.innerText = message;

           
            msgBox.style.marginTop = "15px";
            msgBox.style.padding = "10px";
            msgBox.style.backgroundColor = "#1976d2";
            msgBox.style.color = "#fff";
            msgBox.style.borderRadius = "5px";
            msgBox.style.fontSize = "14px";

            
            this.appendChild(msgBox);

            
            setTimeout(() => {
                if (msgBox.parentNode) {
                    msgBox.remove();
                }
            }, 3000);
        });
    }
});